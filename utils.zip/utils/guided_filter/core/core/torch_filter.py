import multiprocessing
import numpy as np
import cv2
import torch
import torchvision
import PIL
from PIL import Image
import einops
import kornia
import tqdm


def to_32F(image):
    if image.max() > 1.0:
        image = image / 255.0
    return np.clip(np.float32(image), 0, 1)


def cal_inv_multiprocess(matrix):
    """
    Calculate invese matrices using multiprocessing.
    args:
        matrix: (N, m1, m2) N matrices with (m1, m2) shape.
    """
    if len(matrix) > 1000000:
        num_mat_per_process = 1000000
    else:
        num_mat_per_process = 100000
    num_process = len(matrix) // num_mat_per_process + 1
    try:
        multiprocessing.set_start_method('spawn', force=True)
    except RuntimeError:
        pass
    with multiprocessing.Pool(processes=num_process) as pool:
        mat_list = [matrix[i*num_mat_per_process:(i+1)*num_mat_per_process] for i in range(num_process)]
        inverses = pool.map(np.linalg.inv, mat_list)  

    return np.concatenate(inverses)


class GuidedFilter:
    """
    This is a factory class which builds guided filter
    according to the channel number of guided Input.
    The guided input could be gray image, color image,
    or multi-dimensional feature map.

    References:
        K.He, J.Sun, and X.Tang. Guided Image Filtering. TPAMI'12.
    """
    def __init__(self, I, radius, eps, multiprocess=False, device='cuda', filter_type='gaussian'):
        """

        Parameters
        ----------
        I: NDArray
            Guided image or guided feature map
        radius: int
            Radius of filter
        eps: float
            Value controlling sharpness
        """
        if len(I.shape) == 2:
            raise ValueError("Not implemented")
            # self._Filter = GrayGuidedFilter(I, radius, eps)
        else:
            if isinstance(I, np.ndarray):
                I = PIL.Image.fromarray(I)
            self._Filter = MultiDimGuidedFilter(I, radius, eps, multiprocess=multiprocess, filter_type=filter_type)
        self.device=device

    def filter(self, p):
        """

        Parameters
        ----------
        p: NDArray
            Filtering input which is 2D or 3D with format
            HW or HWC

        Returns
        -------
        ret: NDArray
            Filtering output whose shape is same with input
        """
        # p = to_32F(p)
        if isinstance(p, np.ndarray):
            p = PIL.Image.fromarray(p)

        if isinstance(p, torch.Tensor):
            p = p
        elif isinstance(p, PIL.Image.Image):
            p = torchvision.transforms.ToTensor()(p).to(torch.float32)
        p = p.to(self.device)

        if len(p.shape) == 2:
            raise ValueError("Not implemented")
            # return self._Filter.filter(p)
        elif len(p.shape) == 3:
            channels = p.shape[0]
            ret = torch.zeros_like(p)
            for c in tqdm.tqdm(range(channels)):
                ret[c, ...] = self._Filter.filter(p[c, ...])

            ret = ret.permute(1, 2, 0).cpu().numpy()
            return ret
        else:
            raise ValueError("len of p shape should be 2 or 3")


class GrayGuidedFilter:
    """
    Specific guided filter for gray guided image.
    """
    def __init__(self, I, radius, eps):
        """

        Parameters
        ----------
        I: NDArray
            2D guided image
        radius: int
            Radius of filter
        eps: float
            Value controlling sharpness
        """
        self.I = to_32F(I)
        self.radius = radius
        self.eps = eps

    def filter(self, p):
        """

        Parameters
        ----------
        p: NDArray
            Filtering input of 2D

        Returns
        -------
        q: NDArray
            Filtering output of 2D
        """
        # step 1
        meanI  = cv2.blur(src=self.I, ksize=(2 * self.radius + 1, 2 * self.radius + 1))
        meanp  = cv2.blur(src=p, ksize=(2 * self.radius + 1, 2 * self.radius + 1))
        corrI  = cv2.blur(src=self.I * self.I, ksize=(2 * self.radius + 1, 2 * self.radius + 1))
        corrIp = cv2.blur(src=self.I * p, ksize=(2 * self.radius + 1, 2 * self.radius + 1))
        # step 2
        varI   = corrI - meanI * meanI
        covIp  = corrIp - meanI * meanp
        # step 3
        a      = covIp / (varI + self.eps)
        b      = meanp - a * meanI
        # step 4
        meana  = cv2.blur(src=a, ksize=(2 * self.radius + 1, 2 * self.radius + 1))
        meanb  = cv2.blur(src=b, ksize=(2 * self.radius + 1, 2 * self.radius + 1))
        # step 5
        q = meana * self.I + meanb

        return q


class MultiDimGuidedFilter:
    """
    Specific guided filter for color guided image
    or multi-dimensional feature map.
    """
    def __init__(self, I, radius, eps, multiprocess=False, device='cuda', filter_type='gaussian'):
        # self.I = to_32F(I)
        if isinstance(I, torch.Tensor):
            self.I = I
        elif isinstance(I, PIL.Image.Image):
            self.I = torchvision.transforms.ToTensor()(I).to(torch.float32)
        self.I = self.I.to(device)
        
        self.radius = int(radius)
        self.eps = eps
        self.chs  = self.I.shape[0]
        self.rows = self.I.shape[1]
        self.cols = self.I.shape[2]
        self.device = device
        self.multiprocess = multiprocess
        # self.box_filter = kornia.filters.BoxBlur(kernel_size=(2 * self.radius + 1, 2 * self.radius + 1)).to(device)
        # ksize = 2 * self.radius + 1
        # sigma = 0.3*((ksize-1)*0.5 - 1) + 0.8 # https://docs.opencv.org/4.x/d4/d86/group__imgproc__filter.html#gac05a120c1ae92a6060dd0db190a61afa
        sigma = 0.3*(self.radius - 1) + 0.8
        if filter_type=='gaussian':
            print(f"{2 * self.radius + 1}, {sigma=}")
            self._filter = kornia.filters.GaussianBlur2d(kernel_size=(2 * self.radius + 1, 2 * self.radius + 1), sigma=(sigma, sigma)).to(device)
        else:
            self._filter = kornia.filters.BoxBlur(kernel_size=(2 * self.radius + 1, 2 * self.radius + 1), separable=True).to(device)

    def filter(self, p):
        """

        Parameters
        ----------
        p: Torch Tensor
            Filtering input of 2D

        Returns
        -------
        q: Torch Tensor
            Filtering output of 2D
        """
        # self.I = self.I.unsqueeze(0)
        self.I = self.I.reshape(-1, *self.I.shape[-3:])
        p_ = p.unsqueeze(0)
        # meanI = kornia.filters.gaussian_blur2d(self.I, kernel_size=(2 * self.radius + 1, 2 * self.radius + 1))  # (C, H, W)
        # meanp = kornia.filters.gaussian_blur2d(p_, kernel_size=(2 * self.radius + 1, 2 * self.radius + 1)) # (1, H, W)
        meanI = self._filter(self.I)[0] # (C, H, W)
        meanp = self._filter(p_.unsqueeze(0))[0] # (1, H, W)
        # print(f"{meanI.shape=}, {meanp.shape=}")
        
        # meanp = meanp.unsqueeze(0) # (1, H, W)
        I_ = self.I.reshape((self.chs, self.rows*self.cols, 1)) # (C, HW, 1)
        meanI_ = meanI.reshape((self.chs, self.rows*self.cols, 1)) # (C, HW, 1)

        # corrI_ = I_.permute(1, 0, 2) @ I_.permute(1, 2, 0) # (HW, C, C)

        corrI_ = einops.einsum(I_, I_, 'c1 hw j, c2 hw j -> hw c1 c2')
        corrI_ = corrI_.reshape((self.rows, self.cols, self.chs*self.chs)).permute(2, 0, 1) # (CC, H, W)
        corrI_ = self._filter(corrI_.unsqueeze(0)) # , kernel_size=(2 * self.radius + 1, 2 * self.radius + 1))[0]
        corrI = corrI_.reshape((self.chs, self.chs, self.rows*self.cols)).permute(2, 0, 1) # (C, C, HW) -> (HW, C, C)
        corrI = corrI - (meanI_.permute(1, 0, 2) @ meanI_.permute(1, 2, 0))
        
        U = torch.eye(self.chs, device=self.device).unsqueeze(0)

        # left = torch.adjoint(corrI + self.eps * U) / torch.linalg.det(corrI + self.eps * U)
        
        left = torch.linalg.inv(corrI + self.eps * U) # (HW, C, C)
        # left = torch.linalg.inv_ex(corrI + self.eps * U)[0]
        # left = torch.pinverse(corrI + self.eps * U)
        corrIp = self._filter(self.I*p_) # (C, H, W)
        covIp = corrIp - meanI * meanp      # (C, H, W)
        right = covIp.reshape((self.chs, self.rows*self.cols, 1)).permute(1, 0, 2) # (C, HW, 1) -> (HW, C, 1)

        a = left @ right # (HW, C, 1)
        a = a.permute(0, 2, 1) # (HW, 1, C)
        meanI_ = meanI_.permute(1, 0, 2) # (HW, C, 1)
        axmeanI = a @ meanI_
        axmeanI = axmeanI.reshape(self.rows, self.cols, 1)
        b = meanp.permute(1, 2, 0) - axmeanI # (H, W, 1)
        a = a.reshape((self.rows, self.cols, self.chs)).permute(2, 0, 1) # (H, W, C) - > (C, H, W)
        b = b.permute(2, 0, 1) # (1, H, W)
        # print(f"{a.shape=}, {b.shape=}")
        meana = self._filter(a.unsqueeze(0)) # (1, 3, H, W)
        meanb = self._filter(b.unsqueeze(0)) # (1, 1, H, W)
        # print(f"{meana.shape=}, {meanb.shape=}")
        # return  meana + meanb

        meana = meana.reshape((self.chs, self.rows*self.cols, 1)).permute(1, 2, 0) # (HW, 1, C)
        meanb = meanb.reshape((1, self.rows*self.cols, 1)).permute(1, 2, 0)      # (HW, 1, 1)
        I_ = self.I.reshape((self.chs, self.rows*self.cols, 1)).permute(1, 0, 2) # (C, HW, 1) -> (HW, C, 1)

        q = (meana @ I_) + meanb        # (HW, 1, 1)
        q = q.reshape((self.rows, self.cols))

        return q

