from typing import Union
import numpy as np
import imageio
import cv2
import time
import PIL
from PIL import ImageOps

from utils.guided_filter.core.filter import GuidedFilter
from utils.guided_filter.core.torch_filter import GuidedFilter as TorchGuidedFilter

GR = 50  # In the case of longer side has 1024 pixels
GE = -4

def load_image(image_instance):
    if not isinstance(image_instance, np.ndarray):
        image_instance = PIL.Image.open(image_instance)
        image_instance = image_instance.convert("RGB")
        image_instance = ImageOps.exif_transpose(image_instance)
        image_instance = np.array(image_instance)
        print(image_instance.shape)
    return image_instance


def get_target_size(I, width=None, height=None):
    if (width is not None) and (height is not None):
        return (width, height)
    target_size = (I.shape[1], I.shape[0])
    if target_size[1] > 2340:
        target_size = (int(I.shape[1]*(2340/I.shape[0])), 2340)
        if target_size[0] < 1080:
            width = min(I.shape[1], 1080)
            target_size = (width, int(I.shape[0]*width/I.shape[1]))
    return target_size


def apply_guided_filter(
        gen_image: Union[str, np.ndarray],
        guide_image: Union[str, np.ndarray],
        multiprocess = False,
        radius=None,
        epsilon=None,
        filter_type='gaussian',
        width=None,
        height=None
    ):
    p = load_image(gen_image)
    I = load_image(guide_image)

    target_size = get_target_size(I, width, height)
    print(target_size)
    I = cv2.resize(I, target_size, interpolation=cv2.INTER_LINEAR)
    p = cv2.resize(p, target_size, interpolation=cv2.INTER_LINEAR)

    longer = max(target_size[0], target_size[1])
    ratio = longer / 1024
    gr = GR / 2 * ratio if radius is None else radius * ratio
    gr = np.round(gr).astype(int)
    ge = 10**GE if epsilon is None else epsilon

    if filter_type == 'gaussian' or filter_type == 'box':
        GF = TorchGuidedFilter(I, gr, ge, multiprocess=multiprocess, filter_type=filter_type)
    else:
        GF = GuidedFilter(I, gr, ge, multiprocess=multiprocess, filter_type=filter_type)
    out = GF.filter(p) * 255
    print(f"Out shape {out.shape}")
    print(f"Out min: {np.minimum(out,255)}")
    #out = np.maximum(np.minimum(out,255),0)

    print(f'p: {p}')
    # imean = np.mean(I, axis=(0,1))
    # ivar = np.var(I, axis=(0,1))**0.5
    print(f"p shape: {p.shape}")
    print(f"p type: {type(p)}")
    pmean = np.mean(p, axis=(0,1))
    pvar = np.var(p, axis=(0,1))**0.5
    outmean = np.mean(out, axis=(0,1))
    outvar = np.var(out, axis=(0,1))**0.5

    # itop_apply_ratio_mean = 1 / 5
    # itop_apply_ratio_var = 1 / 2
    # normout = (out-outmean)/outvar*(pvar+(ivar-pvar)*itop_apply_ratio_var)+(pmean+(imean-pmean)*itop_apply_ratio_mean)
    normout = (out-outmean)/outvar*pvar+pmean
    normout = np.maximum(np.minimum(normout,255),0)

    return np.uint8(normout)

def do_guided_filter(gen_image, guide_image, out_path='outputs/gf1.jpg', multiprocess=False, radius=None, epsilon=None, filter_type='gaussian', width=None, height=None):
    cur_time = time.time()
    
    normout = apply_guided_filter(gen_image=gen_image, guide_image=guide_image, multiprocess=multiprocess, radius=radius, epsilon=epsilon, filter_type=filter_type, width=width, height=height)

    if out_path.endswith('.jpg'):
        imageio.imsave(out_path, normout, quality=100)
    else:
        imageio.imsave(out_path, normout)

    print(f"Elapsed : {time.time() - cur_time}")
    print('saved to', out_path)

