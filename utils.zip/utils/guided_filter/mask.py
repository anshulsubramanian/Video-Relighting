"""
various masks for masked(adapted) guided filter.
"""

import cv2
import numpy as np

from utils.xdog import XDoG_transform

def normalize(x):
    return (x - np.min(x)) / (np.max(x) - np.min(x) + 1e-6)


def get_mask_white(img: np.ndarray, img_gen: np.ndarray, ksize = (0, 0), sigma = 1) -> np.ndarray:
    """
    Args:
        img: (np.array) original image (h, w, c)
        img_gen: (np.array) generated image with prompt (h, w, c)
        ksize, sigma: ksize and sigma of cv2.GaussianBlur
    Return:
        (np.array, float32) mask [0, 1]. (h, w, 1) shape.
    """

    gray_orig = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
    gray_gen = cv2.cvtColor(img_gen, cv2.COLOR_RGB2GRAY)
    diff_gray = gray_gen.astype(np.float32) - gray_orig.astype(np.float32)

    mask1 = np.zeros_like(diff_gray)
    mask2 = np.zeros_like(diff_gray)
    mask1[gray_gen < 210] = 0.0
    mask1[gray_gen >= 210] = 1.0
    mask2[diff_gray < 60 ] = 0.0
    mask2[diff_gray >= 60 ] = 1.0
    mask = 1 - mask1 * mask2
    mask = mask * 255
    mask = cv2.GaussianBlur(mask, ksize, sigma) / 255
    mask = mask[..., None]

    return mask


def get_mask_edge(img: np.ndarray, img_gen: np.ndarray, ksize = (0, 0), sigma = 100) -> np.ndarray:
    """
    Args:
        img: (np.array) original image (h, w, c)
        img_gen: (np.array) generated image with prompt (h, w, c)
        ksize, sigma: ksize and sigma of cv2.GaussianBlur
    Return:
        (np.array, float32) mask [0, 1]. (h, w, 1) shape.
    """
    # get sketch of images. 0: edge 1: no edge
    edge_orig = XDoG_transform(img)
    edge_gen = XDoG_transform(img_gen)
    # apply GaussianBlur
    edge_orig = cv2.GaussianBlur(edge_orig, ksize, sigma)
    edge_gen = cv2.GaussianBlur(edge_gen, ksize, sigma)

    # normalization [0, 1]. 0: no edge. 1: edge
    edge_orig, edge_gen = 1 - normalize(edge_orig), 1 - normalize(edge_gen)

    # get difference of blurred edges
    diff_edge = edge_gen - edge_orig
    # normalize and reshape (h, w) -> (h, w, 1)
    diff_edge = normalize(diff_edge)[..., None]

    return diff_edge

def get_mask_color_diff(img: np.ndarray, img_gen: np.ndarray) -> np.ndarray:
    """
    Args:
        img: (np.array) original image (h, w, c)
        img_gen: (np.array) generated image with prompt (h, w, c)
    Return:
        (np.array, float32) mask [0, 1]. (h, w, 1) shape.
    """
    org_w, org_h = img.shape[1], img.shape[0]

    max_edge = max(img.shape[0], img.shape[1])
    if max_edge > 1024:
        h = int(img.shape[0] * 1024 / max_edge + 0.5) // 8 * 8
        w = int(img.shape[1] * 1024 / max_edge + 0.5) // 8 * 8
        img = cv2.resize(img, dsize=(w, h), interpolation=cv2.INTER_LINEAR)
        img_gen = cv2.resize(img_gen, dsize=(w, h), interpolation=cv2.INTER_LINEAR)

    edge_orig = normalize(XDoG_transform(img))
    edge_gen = normalize(XDoG_transform(img_gen))

    edge_orig[edge_orig < 0.5] = 0.0
    edge_orig[edge_orig >= 0.5] = 1.0
    edge_gen[edge_gen < 0.5] = 0.0
    edge_gen[edge_gen >= 0.5] = 1.0

    edge_orig = 1 - edge_orig
    edge_gen = 1 - edge_gen

    mask = edge_orig * edge_gen

    img_color_flat = img[mask == 1].flatten()
    img_color_mean = img_color_flat.mean()
    img_color_var = img_color_flat.var()
    img_gen_color_flat = img_gen[mask == 1].flatten()
    img_gen_color_mean = img_gen_color_flat.mean()
    img_gen_color_var = img_gen_color_flat.var()

    img_color_adj = np.array(normalize((img - img_color_mean) / img_color_var)*255, dtype=np.uint8)
    img_gen_color_adj = np.array(normalize((img_gen - img_gen_color_mean) / img_gen_color_var)*255, dtype=np.uint8)

    img_gray = cv2.cvtColor(img_color_adj, cv2.COLOR_BGR2GRAY)
    img_gen_gray = cv2.cvtColor(img_gen_color_adj, cv2.COLOR_BGR2GRAY)

    img_gray_mean = img_gray.mean()
    img_gen_gray_mean = img_gen_gray.mean()

    diff_res = normalize(img_gray - img_gray_mean) - normalize(img_gen_gray - img_gen_gray_mean)
    diff_res = normalize(diff_res)
    # mask_step1 = np.array(diff_res*255, dtype=np.uint8)

    mask = np.zeros_like(diff_res)
    mask[diff_res < 0.35] = 0.0
    mask[diff_res >= 0.35] = 1.0

    # mask_step2 = np.array(mask*255, dtype=np.uint8)
    mask = cv2.GaussianBlur(mask, (0, 0), 5)

    # mask_step3 = np.array(mask*255, dtype=np.uint8)

    after_gauss_blur_threshold = 0.45
    mask[mask < after_gauss_blur_threshold] = 0.0
    mask[mask >= after_gauss_blur_threshold] = 1.0

    # mask_step4 = np.array(mask*255, dtype=np.uint8)

    # mask_big = cv2.GaussianBlur(mask, (0, 0), 30)
    mask_small = cv2.GaussianBlur(mask, (0, 0), 15)

    final = np.zeros_like(mask)
    final[mask == 0] = mask_small[mask == 0]
    final[mask == 1] = 1

    mask = final.clip(0.3, 1.0)

    if org_w != final.shape[1] or org_h != final.shape[0]:
        mask = cv2.resize(mask, dsize=(org_w, org_h), interpolation=cv2.INTER_LINEAR)

    mask = mask[..., None]

    return mask

