import cv2
import numpy as np

def _XDoG(img, gamma=0.98, phi=200, epsilon=0.1, kappa=1.6, sigma=0.8):
    gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
    gFiltered1 = cv2.GaussianBlur(gray, (11, 11), sigma)
    gFiltered2 = cv2.GaussianBlur(gray, (11, 11), kappa*sigma)
    diff = gFiltered1 - (gamma*gFiltered2)
    xdog = np.zeros_like(diff)
    mask = diff > epsilon
    mask_neg = np.logical_not(mask)
    xdog[mask] = 1.
    xdog[mask_neg] = 1. + np.tanh(phi*(diff[mask_neg]-epsilon))
    return xdog

def XDoG_transform(img, gamma=0.98, phi=200, epsilon=0.00001, kappa=1.6, sigma=0.8, use_blurry_input=True):
    """
    Winnemöller, Holger, Jan Eric Kyprianidis, and Sven C. Olsen. 
    "XDoG: An eXtended difference-of-Gaussians compendium including advanced image stylization." 2012
    python version of XDog (modified). Convert colored image to sketch.
    Args:
        img: (np.array) colored RGB image with shape (h, w, c)
    Return:
        (np.array, float32) sketch image with range [0, 1]. (h, w) shape.
    """
    if use_blurry_input:
        h, w = img.shape[:2]
        ksize = int(np.sqrt(h*w*5*5/256/256))
        if ksize % 2 == 0:
            ksize += 1
        img = cv2.GaussianBlur(img, (ksize, ksize), 0.7).astype(np.float32)
    xdog = _XDoG(img, gamma, phi, epsilon, kappa, sigma)
    return xdog.astype(np.float32)

