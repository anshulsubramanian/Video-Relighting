from PIL import Image
import torch
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as T
import random
import os
import json
import shutil 

class dataset(Dataset):
    def __init__(self, sunny_images, snowy_images, img_size = 512):
        self.img_paths = sunny_images + snowy_images
        self.labels = [[1, 0]] * len(sunny_images) + [[0, 1]] * len(snowy_images) 
        self.transform = T.Compose([
            T.Resize((img_size, img_size)),
            T.ToTensor(), 
            T.Normalize([0.5] * 3, [0.5] * 3)
        ])

    def __len__(self):
        return len(self.img_paths)

    def __getitem__(self, idx):
        path = self.img_paths[idx] 
        img = Image.open(path).convert('RGB')
        label = torch.tensor(self.labels[idx], dtype = torch.float32)

        return self.transform(img), label


class paired_dataset(Dataset):
    def __init__(self, sunny_images, snowy_images, img_width = 512, img_height = 512):

        assert len(sunny_images) == len(snowy_images), "Mismatch in paired image count"

        self.sunny = sorted(sunny_images)
        self.snowy = sorted(snowy_images)
                
        self.transform = T.Compose([
            T.Resize((img_width, img_height)),
            T.ToTensor(), 
            T.Normalize([0.5] * 3, [0.5] * 3)
        ])

    def __len__(self):
        return len(self.sunny)

    def __getitem__(self, idx):
        
        sunny_img = Image.open(self.sunny[idx]).convert('RGB')
        snowy_img = Image.open(self.snowy[idx]).convert('RGB')

        sunny_img = self.transform(sunny_img)
        snowy_img = self.transform(snowy_img)
        
        return {
            "sunny" : sunny_img,
            "snowy" : snowy_img,
            "src" : 0,
            "trg" : 1
        }
    
    


class multi_class_dataset(Dataset):
    
    def __init__(self, input_path, ground_truth_path, img_size = 512):
        self.input_path = input_path
        self.input = sorted(os.listdir(self.input_path))
        
        self.ground_truth_path = ground_truth_path
        
        for folder in os.listdir(self.ground_truth_path):
            if folder == 'evening':
                self.evening_path = os.path.join(ground_truth_path, folder)
            elif folder == 'night':
                self.night_path = os.path.join(ground_truth_path, folder)
            elif folder == 'snowy':
                self.snowy_path = os.path.join(ground_truth_path, folder)
            elif folder == 'rainy':
                self.rainy_path = os.path.join(ground_truth_path, folder)
            elif folder == 'rainy_night':
                self.rainy_night_path = os.path.join(ground_truth_path, folder)
            elif folder == 'snowy_evening':
                self.snowy_evening_path = os.path.join(ground_truth_path, folder)
            elif folder == 'snowy_night':
                self.snowy_night_path = os.path.join(ground_truth_path, folder)
           
        
        self.evening = sorted(os.listdir(self.evening_path))
        self.night = sorted(os.listdir(self.night_path))
        self.snowy = sorted(os.listdir(self.snowy_path))
        self.rainy = sorted(os.listdir(self.rainy_path))
        self.rainy_night = sorted(os.listdir(self.rainy_night_path))
        self.snowy_evening = sorted(os.listdir(self.snowy_evening_path))
        self.snowy_night = sorted(os.listdir(self.snowy_night_path))
        
        if self.evening[0].endswith('checkpoint') or self.evening[0].endswith('checkpoints'):
            self.evening = self.evening[1:]
        
        if self.night[0].endswith('checkpoint') or self.night[0].endswith('checkpoints'):
            self.night = self.night[1:]
            
        if self.snowy[0].endswith('checkpoint') or self.snowy[0].endswith('checkpoints'):
            self.snowy = self.snowy[1:]
        
        if self.rainy[0].endswith('checkpoint') or self.rainy[0].endswith('checkpoints'):
            self.rainy = self.rainy[1:]
        
        if self.rainy_night[0].endswith('checkpoint') or self.rainy_night[0].endswith('checkpoints'):
            self.rainy_night = self.rainy_night[1:]
        
        if self.snowy_night[0].endswith('checkpoint') or self.snowy_night[0].endswith('checkpoints'):
            self.snowy_night = self.snowy_night[1:]
        
        if self.snowy_evening[0].endswith('checkpoint') or self.snowy_evening[0].endswith('checkpoints'):
            self.snowy_evening = self.snowy_evening[1:]
            
        if self.input[0].endswith('checkpoint') or self.input[0].endswith('checkpoints'):
            self.input = self.input[1:]
        
        print(len(self.input))
        print(len(self.evening))
        print(len(self.snowy))
        print(len(self.night))
        print(len(self.rainy))
        print(len(self.snowy_evening))
        print(len(self.snowy_night))
        print(len(self.rainy_night))
        
        print(self.input[0:10])
        print(self.evening[0:10])
        print(self.snowy[0:10])
        print(self.night[0:10])
        print(self.rainy[0:10])
        print(self.snowy_evening[0:10])
        print(self.snowy_night[0:10])
        print(self.rainy_night[0:10])
        
        
        self.transform = T.Compose([
            T.Resize((img_size, img_size)),
            T.ToTensor(), 
            T.Normalize([0.5] * 3, [0.5] * 3)
        ])
              
    def __len__(self):
        return len(self.snowy)


    def __getitem__(self, idx):
        input_image = self.transform(Image.open(os.path.join(self.input_path, self.input[idx])))
        
        evening_image = self.transform(Image.open(os.path.join(self.evening_path,self.evening[idx])))
        night_image = self.transform(Image.open(os.path.join(self.night_path,self.night[idx])))
        snowy_image = self.transform(Image.open(os.path.join(self.snowy_path,self.snowy[idx])))
        rainy_image = self.transform(Image.open(os.path.join(self.rainy_path,self.rainy[idx])))
        snowy_evening_image = self.transform(Image.open(os.path.join(self.snowy_evening_path,self.snowy_evening[idx])))
        snowy_night_image = self.transform(Image.open(os.path.join(self.snowy_night_path, self.snowy_night[idx])))
        rainy_night_image = self.transform(Image.open(os.path.join(self.rainy_night_path, self.rainy_night[idx])))
        
        #['evening', 'night', 'rainy', 'rainy_night', 'snowy', 'snowy_evening', 'snowy_night']
        return input_image, [evening_image, night_image, rainy_image, rainy_night_image, snowy_image, snowy_evening_image, snowy_night_image]
            
    
    
    
    
    
class main_dataset(Dataset):
    
    def __init__(self, input_path, ground_truth_path, img_size = 512):
        self.input_path = input_path
        self.ground_truth_path = ground_truth_path
        
        self.input = sorted(os.listdir(self.input_path))
        
        if self.input[0].endswith('checkpoint') or self.input[0].endswith('checkpoints'):
            self.input = self.input[1:]
            
        
        self.master_input = []
        self.master_gt = []
        self.master_label = []
        
        #['evening', 'night', 'rainy', 'rainy_night', 'snowy', 'snowy_evening', 'snowy_night']
        evening = os.path.join(self.ground_truth_path, "evening") #0
        night = os.path.join(self.ground_truth_path, "night") #1
        rainy = os.path.join(self.ground_truth_path, "rainy") #2
        rainy_night = os.path.join(self.ground_truth_path, "rainy_night") #3
        snowy = os.path.join(self.ground_truth_path, "snowy") #4
        snowy_evening = os.path.join(self.ground_truth_path, "snowy_evening") #5
        snowy_night = os.path.join(self.ground_truth_path, "snowy_night") #6
        
        not_found = []
        print(f"Evening: {len(os.listdir(evening))}")
        print(f"Night: {len(os.listdir(night))}")
        print(f"Rainy: {len(os.listdir(rainy))}")
        print(f"Rainy Night: {len(os.listdir(rainy_night))}")
        print(f"Snowy: {len(os.listdir(snowy))}")
        print(f"Snowy Evening: {len(os.listdir(snowy_evening))}")
        print(f"Snowy Night: {len(os.listdir(snowy_night))}")
        for image in self.input:
            
            image_path = os.path.join(self.input_path, image)
            
            image_name = image.split('.')[0]
            
            evening_name = image_name + '_evening.png' #0
            night_name = image_name + '_night.png' #1
            rainy_name = image_name + '_rainy.png' #2
            rainy_night_name = image_name + '_night, rainy.png' #3
            snowy_name = image_name + '_snowy.png' #4
            snowy_evening_name = image_name + '_evening, snowy.png' #5
            snowy_night_name = image_name + '_night, snowy.png' #6
            
            
            if os.path.exists(os.path.join(evening, evening_name)):
                self.master_input.append(image_path)
                self.master_gt.append(os.path.join(evening, evening_name))
                self.master_label.append(0)
            else:
                not_found.append(image_name)
                
            if os.path.exists(os.path.join(night, night_name)):
                self.master_input.append(image_path)
                self.master_gt.append(os.path.join(night, night_name))
                self.master_label.append(1)
            
            if os.path.exists(os.path.join(rainy, rainy_name)):
                self.master_input.append(image_path)
                self.master_gt.append(os.path.join(rainy, rainy_name))
                self.master_label.append(2)
            
            if os.path.exists(os.path.join(rainy_night, rainy_night_name)):
                self.master_input.append(image_path)
                self.master_gt.append(os.path.join(rainy_night, rainy_night_name))
                self.master_label.append(3)
            
            
            if os.path.exists(os.path.join(snowy, snowy_name)):
                self.master_input.append(image_path)
                self.master_gt.append(os.path.join(snowy, snowy_name))
                self.master_label.append(4)
            
            if os.path.exists(os.path.join(snowy_evening, snowy_evening_name)):
                self.master_input.append(image_path)
                self.master_gt.append(os.path.join(snowy_evening, snowy_evening_name))
                self.master_label.append(5)

            if os.path.exists(os.path.join(snowy_night, snowy_night_name)):
                self.master_input.append(image_path)
                self.master_gt.append(os.path.join(snowy_night, snowy_night_name))
                self.master_label.append(6)

        with open("not_found.txt", 'w') as f:
            for image in not_found:
                f.write(f"{image}\n")
                
        
#         print("Now we load HQ Dataset")        
        
#         curr_size = len(self.master_input) // 7 
        
#         weathers = {'evening' : curr_size, 'night' : curr_size, 'rainy' : curr_size, 'night, rainy' : curr_size, 'snowy': curr_size, 'evening, snowy': curr_size, 'night, snowy' : curr_size}
#         labels = {'evening' : 0, 'night' : 1, 'rainy' : 2, 'night, rainy' : 3, 'snowy': 4, 'evening, snowy': 5, 'night, snowy' : 6}
        
#         path = "/home/work/GAN_based_Live_Wallpaper/dataset/dataset_hq/wallpaper_dataset_ver1.5/"
        
#         all_files = len(os.listdir(path)) * 0.9
#         all_files = int(all_files)
#         val_path = "/home/work/GAN_based_Live_Wallpaper/dataset/dataset_hq/val"
#         os.makedirs(val_path, exist_ok = True)
        
        #Read each folder
#         for i, folder in enumerate(os.listdir(path)):
            
                
#             if folder.endswith("checkpoint") or folder == "seeds.json":
#                 continue
        
#             folder_path = os.path.join(path, folder)
    
# #             if i < all_files:
#             label = -1
#             input_path = ""
#             output_paths = ""

#             #Read the files inside each folder
#             for file in os.listdir(folder_path):
#                 file_path = os.path.join(folder_path, file)

#                 if file.endswith(".json"):
#                     with open(file_path, "r") as f:
#                         data = json.load(f)

#                     if data["edit"]  in weathers.keys():
#                         #print(f"{i} Increasing count")
#                         weathers[data["edit"]] = weathers[data["edit"]] + 1
#                         label = labels[data["edit"]]

#                 if file.endswith("0.jpg"):
#                     input_path = file_path

#                 if file.endswith("1.jpg"):
#                     output_path = file_path

#                 #Read Each file end

#             #Store data if valid
#             if label != -1 and input_path != "" and output_path != "":
#                 #print(f"{i} Storing data")
#                 self.master_label.append(label)
#                 self.master_input.append(input_path)
#                 self.master_gt.append(output_path)

# #             else:
# #                 shutil.move(folder_path, val_path)
        
        self.transform = T.Compose([
            T.Resize((img_size, img_size)),
            T.ToTensor(), 
            T.Normalize([0.5] * 3, [0.5] * 3)
        ])
        
#         print(weathers)
        
        #print(f"This should be around {(4933 * 7) + 24200}")
        print(len(self.master_input))
        print(len(self.master_gt))
        print(len(self.master_label))
              
    def __len__(self):
        return len(self.master_input)


    def __getitem__(self, idx):
        input_image = self.transform(Image.open(self.master_input[idx]))
        gt_image = self.transform(Image.open(self.master_gt[idx]))
        label = self.master_label[idx]
        
        return input_image, gt_image, label
        
