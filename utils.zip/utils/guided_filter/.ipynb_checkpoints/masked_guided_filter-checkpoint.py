from typing import Union, Optional
import time
import cv2
import imageio
import numpy as np

from utils.guided_filter import apply_guided_filter, get_mask_white, get_mask_edge, get_mask_color_diff

def apply_masked_guided_filter(
        gen_image: Union[str, np.ndarray], 
        guide_image: Union[str, np.ndarray], 
        gf_image: Optional[Union[str, np.ndarray]] = None, 
        snowy_image: Optional[Union[str, np.ndarray]] = None, 
        mask_type = 'edge',
        multiprocess = False) -> np.ndarray:
    """
    args:
        gen_image: path or np.array of generated image. If path is given, read image.
        guide_image: path or np.array of original image. If path is given, read image.
        gf_image: path or np.array of gf image. If path is given, read image. If gf_image=None, generate image applied guided filter.
        gen_image_snowy: path or np.array of snowy image. 
        mask_type: 'edge', 'color', 'white', 'white_snowy'
    return:
        image applied masked guided filter.
    """
    
    if isinstance(gen_image, str):
        gen_image = imageio.imread(gen_image)
    if isinstance(guide_image, str):
        guide_image = imageio.imread(guide_image)

    if isinstance(gf_image, str):
        gf_image = imageio.imread(gf_image)
    elif gf_image is None:
        gf_image = apply_guided_filter(gen_image, guide_image, multiprocess=multiprocess)

    h, w = gf_image.shape[:2]
    gen_image = cv2.resize(gen_image, dsize=(w, h), interpolation=cv2.INTER_LANCZOS4)
    guide_image = cv2.resize(guide_image, dsize=(w, h), interpolation=cv2.INTER_LANCZOS4)

    if mask_type == 'edge':
        mask = get_mask_edge(guide_image, gen_image, ksize=(0, 0), sigma=100)
        # weighted sum with mask
        res = gf_image * mask + gen_image * (1-mask)
 
    elif mask_type == 'white':
        mask = get_mask_white(guide_image, gen_image, ksize=(0, 0), sigma=1)
        # weighted sum with mask
        res = gf_image * mask + gen_image * (1-mask)

    elif mask_type == 'white_snowy':
        assert snowy_image is not None, "path or np.array"
        if isinstance(snowy_image, str):
            snowy_image = imageio.imread(snowy_image)
        snowy_image = cv2.resize(snowy_image, dsize=(w, h), interpolation=cv2.INTER_LANCZOS4)
        mask_white_showy = get_mask_white(guide_image, snowy_image, ksize=(0, 0), sigma=1)
        # weighted sum with white mask from snowy
        res = gf_image * mask_white_showy + gen_image * (1-mask_white_showy)
        
    elif mask_type == 'color':
        mask = get_mask_color_diff(guide_image, gen_image)
        imean = np.mean(guide_image, axis=(0,1))
        ivar = np.var(guide_image, axis=(0,1))**0.5
        pmean = np.mean(gen_image, axis=(0,1))
        pvar = np.var(gen_image, axis=(0,1))**0.5
        gfmean = np.mean(gf_image, axis=(0,1))
        gfvar = np.var(gf_image, axis=(0,1))**0.5

        itop_apply_ratio_mean = 1 / 5
        itop_apply_ratio_var = 1 / 2

        gf_image_adj = (gf_image-gfmean)/gfvar*(pvar+(ivar-pvar)*itop_apply_ratio_var)+(pmean+(imean-pmean)*itop_apply_ratio_mean)
        gf_image_adj = np.maximum(np.minimum(gf_image_adj, 255), 0)

        gen_image_adj = (gen_image-pmean)/pvar*(pvar+(ivar-pvar)*itop_apply_ratio_var)+(pmean+(imean-pmean)*itop_apply_ratio_mean)
        gen_image_adj = np.maximum(np.minimum(gen_image_adj, 255), 0)

        # weighted sum with mask
        res = gf_image_adj * mask + gen_image_adj * (1-mask)
        
    else:
        raise NotImplementedError

    return np.uint8(res)

def do_masked_guided_filter(
        gen_image: Union[str, np.ndarray], 
        guide_image: Union[str, np.ndarray], 
        gf_image: Optional[Union[str, np.ndarray]] = None, 
        snowy_image: Optional[Union[str, np.ndarray]] = None, 
        mask_type = 'white',
        out_path = 'outputs/gf_masked_edge_image.png',
        multiprocess = False):
    
    """
    Generate image with masked filter and Save it.
    args:
        gen_image: path or np.array of generated image. If path is given, read image.
        guide_image: path or np.array of original image. If path is given, read image.
        gf_image: path or np.array of gf image. If path is given, read image. If gf_image=None, generate image applied guided filter.
        snowy_image: path or np.array of snowy image. 
        mask_type: 'edge', 'color', 'white', 'white_snowy'
        out_path: path of saved image.
    """
    cur_time = time.time()
    
    res = apply_masked_guided_filter(
        gen_image=gen_image, guide_image=guide_image, gf_image=gf_image, snowy_image=snowy_image,
        mask_type=mask_type, multiprocess=multiprocess)

    if out_path.endswith('.jpg'):
        imageio.imsave(out_path, res, quality=100)
    else:
        imageio.imsave(out_path, res)

    print(f"Elapsed : {time.time() - cur_time}")
    print('saved to', out_path)

if __name__ == "__main__":
    do_masked_guided_filter(
        guide_image="inputs/test_35.jpg",
        gen_image="outputs/test_35_morning, snowy.png",
        out_path="result_masked_gf.png"
    )
