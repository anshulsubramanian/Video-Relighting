import multiprocessing
import numpy as np
import cv2


def to_32F(image):
    if image.max() > 1.0:
        image = image / 255.0
    return np.clip(np.float32(image), 0, 1)


def cal_inv_multiprocess(matrix):
    """
    Calculate invese matrices using multiprocessing.
    args:
        matrix: (N, m1, m2) N matrices with (m1, m2) shape.
    """
    if len(matrix) > 1000000:
        num_mat_per_process = 1000000
    else:
        num_mat_per_process = 100000
    num_process = len(matrix) // num_mat_per_process + 1
    try:
        multiprocessing.set_start_method('spawn', force=True)
    except RuntimeError:
        pass
    with multiprocessing.Pool(processes=num_process) as pool:
        mat_list = [matrix[i*num_mat_per_process:(i+1)*num_mat_per_process] for i in range(num_process)]
        inverses = pool.map(np.linalg.inv, mat_list)  

    return np.concatenate(inverses)


class GuidedFilter:
    """
    This is a factory class which builds guided filter
    according to the channel number of guided Input.
    The guided input could be gray image, color image,
    or multi-dimensional feature map.

    References:
        K.He, J.Sun, and X.Tang. Guided Image Filtering. TPAMI'12.
    """
    def __init__(self, I, radius, eps, multiprocess=False, filter_type='gaussian'):
        """

        Parameters
        ----------
        I: NDArray
            Guided image or guided feature map
        radius: int
            Radius of filter
        eps: float
            Value controlling sharpness
        """
        if len(I.shape) == 2:
            self._Filter = GrayGuidedFilter(I, radius, eps)
        else:
            self._Filter = MultiDimGuidedFilter(I, radius, eps, multiprocess=multiprocess, filter_type=filter_type)

    def filter(self, p):
        """

        Parameters
        ----------
        p: NDArray
            Filtering input which is 2D or 3D with format
            HW or HWC

        Returns
        -------
        ret: NDArray
            Filtering output whose shape is same with input
        """
        p = to_32F(p)
        if len(p.shape) == 2:
            return self._Filter.filter(p)
        elif len(p.shape) == 3:
            channels = p.shape[2]
            ret = np.zeros_like(p, dtype=np.float32)
            for c in range(channels):
                ret[:, :, c] = self._Filter.filter(p[:, :, c])
            return ret


class GrayGuidedFilter:
    """
    Specific guided filter for gray guided image.
    """
    def __init__(self, I, radius, eps):
        """

        Parameters
        ----------
        I: NDArray
            2D guided image
        radius: int
            Radius of filter
        eps: float
            Value controlling sharpness
        """
        self.I = to_32F(I)
        self.radius = radius
        self.eps = eps

    def filter(self, p):
        """

        Parameters
        ----------
        p: NDArray
            Filtering input of 2D

        Returns
        -------
        q: NDArray
            Filtering output of 2D
        """
        # step 1
        meanI  = cv2.blur(src=self.I, ksize=(2 * self.radius + 1, 2 * self.radius + 1))
        meanp  = cv2.blur(src=p, ksize=(2 * self.radius + 1, 2 * self.radius + 1))
        corrI  = cv2.blur(src=self.I * self.I, ksize=(2 * self.radius + 1, 2 * self.radius + 1))
        corrIp = cv2.blur(src=self.I * p, ksize=(2 * self.radius + 1, 2 * self.radius + 1))
        # step 2
        varI   = corrI - meanI * meanI
        covIp  = corrIp - meanI * meanp
        # step 3
        a      = covIp / (varI + self.eps)
        b      = meanp - a * meanI
        # step 4
        meana  = cv2.blur(src=a, ksize=(2 * self.radius + 1, 2 * self.radius + 1))
        meanb  = cv2.blur(src=b, ksize=(2 * self.radius + 1, 2 * self.radius + 1))
        # step 5
        q = meana * self.I + meanb

        return q


class MultiDimGuidedFilter:
    """
    Specific guided filter for color guided image
    or multi-dimensional feature map.
    """
    def __init__(self, I, radius, eps, multiprocess=False, filter_type='gaussian'):
        self.I = to_32F(I)
        self.radius = radius
        self.eps = eps

        self.rows = self.I.shape[0]
        self.cols = self.I.shape[1]
        self.chs  = self.I.shape[2]

        self.multiprocess = multiprocess
        self.filter_type=filter_type
        assert self.filter_type in ['gaussian', 'box']

    def filter(self, p):
        """

        Parameters
        ----------
        p: NDArray
            Filtering input of 2D

        Returns
        -------
        q: NDArray
            Filtering output of 2D
        """

        assert self.filter_type in ['gaussian', 'box']
        p_ = np.expand_dims(p, axis=2)

        if self.filter_type == 'box':
            meanI = cv2.blur(src=self.I, ksize=(2 * self.radius + 1, 2 * self.radius + 1)) # (H, W, C)
            meanp = cv2.blur(src=p_, ksize=(2 * self.radius + 1, 2 * self.radius + 1)) # (H, W, 1)
        elif self.filter_type == 'gaussian':
            meanI = cv2.GaussianBlur(src=self.I, ksize=(2 * self.radius + 1, 2 * self.radius + 1), sigmaX=0) # (H, W, C)
            meanp = cv2.GaussianBlur(src=p_, ksize=(2 * self.radius + 1, 2 * self.radius + 1), sigmaX=0) # (H, W, 1)
        
        meanp = np.expand_dims(meanp, axis=2)
        I_ = self.I.reshape((self.rows*self.cols, self.chs, 1)) # (HW, C, 1)
        meanI_ = meanI.reshape((self.rows*self.cols, self.chs, 1)) # (HW, C, 1)

        corrI_ = np.matmul(I_, I_.transpose(0, 2, 1))  # (HW, C, C)
        corrI_ = corrI_.reshape((self.rows, self.cols, self.chs*self.chs)) # (H, W, CC)
        if self.filter_type == 'box':
            corrI_ = cv2.blur(src=corrI_, ksize=(2 * self.radius + 1, 2 * self.radius + 1))
        elif self.filter_type == 'gaussian':
            corrI_ = cv2.GaussianBlur(src=corrI_, ksize=(2 * self.radius + 1, 2 * self.radius + 1), sigmaX=0)
        corrI = corrI_.reshape((self.rows*self.cols, self.chs, self.chs)) # (HW, C, C)
        corrI = corrI - np.matmul(meanI_, meanI_.transpose(0, 2, 1))

        U = np.expand_dims(np.eye(self.chs, dtype=np.float32), axis=0)
        # U = np.tile(U, (self.rows*self.cols, 1, 1)) # (HW, C, C)

        # calculate inverse matrix
        if self.multiprocess:
            # calculate inverse matrix using multiprocess
            left = cal_inv_multiprocess(corrI + self.eps * U) # (HW, C, C)
        else:
            left = np.linalg.inv(corrI + self.eps * U) # (HW, C, C)

        if self.filter_type == 'box':
            corrIp = cv2.blur(src=self.I*p_, ksize=(2 * self.radius + 1, 2 * self.radius + 1)) # (H, W, C)
        elif self.filter_type == 'gaussian':
            corrIp = cv2.GaussianBlur(src=self.I*p_, ksize=(2 * self.radius + 1, 2 * self.radius + 1), sigmaX=0) # (H, W, C)
        covIp = corrIp - meanI * meanp # (H, W, C)
        right = covIp.reshape((self.rows*self.cols, self.chs, 1)) # (HW, C, 1)

        a = np.matmul(left, right) # (HW, C, 1)
        axmeanI = np.matmul(a.transpose((0, 2, 1)), meanI_) # (HW, 1, 1)
        axmeanI = axmeanI.reshape((self.rows, self.cols, 1))
        b = meanp - axmeanI # (H, W, 1)
        a = a.reshape((self.rows, self.cols, self.chs))
        if self.filter_type == 'box':
            meana = cv2.blur(src=a, ksize=(2 * self.radius + 1, 2 * self.radius + 1))
            meanb = cv2.blur(src=b, ksize=(2 * self.radius + 1, 2 * self.radius + 1))
        elif self.filter_type == 'gaussian':
            meana = cv2.GaussianBlur(src=a, ksize=(2 * self.radius + 1, 2 * self.radius + 1), sigmaX=0)
            meanb = cv2.GaussianBlur(src=b, ksize=(2 * self.radius + 1, 2 * self.radius + 1), sigmaX=0)

        meana = meana.reshape((self.rows*self.cols, 1, self.chs))
        meanb = meanb.reshape((self.rows*self.cols, 1, 1))
        I_ = self.I.reshape((self.rows*self.cols, self.chs, 1))

        q = np.matmul(meana, I_) + meanb
        q = q.reshape((self.rows, self.cols))

        return q
